/**
 * MOJOWAY Company Info - Single Source of Truth (Client-side)
 * This file is auto-generated from /config/company_info.json
 * DO NOT EDIT MANUALLY - edit company_info.json and run sync_company_info.py
 */

const COMPANY_INFO = {
    legalName: "Mojoway Spectrum Limited",
    legalNameShort: "MOJOWAY",
    registrationNumber: "80630518",
    registrationCountry: "Hong Kong SAR, China",
    legalAddress: "Unit D07, 8/F, Kai Tak Factory Building Phase 2, 99 King Fuk Street, San Po Kong, Hong Kong",
    governingLaw: "Hong Kong Special Administrative Region",
    companyType: "Private Limited Company",
    supportEmail: "support@mojowaylife.com",
    founderEmail: "brian@mojowaylife.com"
};

/**
 * Auto-fill footer copyright and company info on DOMContentLoaded
 */
document.addEventListener('DOMContentLoaded', function() {
    // Fill copyright in footer
    var footers = document.querySelectorAll('footer');
    footers.forEach(function(footer) {
        // Fill copyright
        var copyright = footer.querySelector('.copyright, .footer-copyright, #copyright');
        if (copyright) {
            copyright.textContent = '\u00A9 ' + new Date().getFullYear() + ' ' + COMPANY_INFO.legalName + '. All rights reserved.';
        }

        // Fill company name spans
        var nameSpans = footer.querySelectorAll('[data-company-name]');
        nameSpans.forEach(function(el) {
            el.textContent = COMPANY_INFO.legalName;
        });

        // Fill support email links
        var supportLinks = footer.querySelectorAll('[data-support-email]');
        supportLinks.forEach(function(el) {
            el.textContent = COMPANY_INFO.supportEmail;
            el.href = 'mailto:' + COMPANY_INFO.supportEmail;
        });

        // Fill registration number
        var regNums = footer.querySelectorAll('[data-reg-number]');
        regNums.forEach(function(el) {
            el.textContent = COMPANY_INFO.registrationNumber;
        });
    });

    // Fill any global data-* attributes
    var nameEls = document.querySelectorAll('[data-company-name]');
    nameEls.forEach(function(el) {
        if (!el.closest('footer')) el.textContent = COMPANY_INFO.legalName;
    });

    var emailEls = document.querySelectorAll('[data-support-email]');
    emailEls.forEach(function(el) {
        if (!el.closest('footer')) {
            el.textContent = COMPANY_INFO.supportEmail;
            el.href = 'mailto:' + COMPANY_INFO.supportEmail;
        }
    });
});
